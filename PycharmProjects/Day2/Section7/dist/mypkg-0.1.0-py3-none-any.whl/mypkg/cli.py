# mypkg/cli.py
def main():
    print("Hello from mytool!")
