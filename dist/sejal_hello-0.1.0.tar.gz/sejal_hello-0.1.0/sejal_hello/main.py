def say_hello(name="World"):
    print(f"Hello, {name}!")
