def main():
    print("Hello from sejal-hello!")


if __name__ == "__main__":
    main()
